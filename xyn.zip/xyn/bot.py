from itertools import count
# from webbrowser import Firefox
import requests
from bs4 import BeautifulSoup as bs 
import re 
import os 
import random
from fake_useragent import UserAgent
from collections import OrderedDict
import socket
from selenium.webdriver.common.proxy import Proxy, ProxyType
from selenium import webdriver
# from webdriver_manager.chrome import ChromeDriverManager
# from selenium.webdriver.chrome.options import Options
# from selenium.webdriver.support.wait import WebDriverWait
# from selenium.webdriver.support import expected_conditions as EC
# from selenium.webdriver.common.keys import Keys
# from selenium.webdriver.common.by import By
# import chromedriver_autoinstaller as chromedriver
# from selenium.webdriver.chrome.service import Service
from webdriver_manager.firefox import GeckoDriverManager
from selenium.webdriver.firefox.options import Options
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.proxy import Proxy, ProxyType
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.firefox.service import Service
from colorama import Fore
import time 
from random import randrange as rang
from datetime import datetime
import socket
import threading
from concurrent import futures


ua = UserAgent()


# head = {'User-Agent': ua.random}

# COLORS 

purp = Fore.MAGENTA
red = Fore.RED
yellow = Fore.YELLOW
test = Fore.LIGHTMAGENTA_EX
brown = Fore.CYAN
blue = Fore.BLUE
green = Fore.GREEN
# BACKGROUND
ply = []
poll = []
def cls():
    os.system('cls' if os.name=='nt' else 'clear')
    pass


sleep = time.sleep

now = datetime.now()
curr = now.strftime("%d_%m_%Y.%H_%M")


sclink = input('Enter Soundcloud Link: ')
amt = input('Enter How Many Plays Do You Want ?: ')



os.environ['GH_TOKEN'] = "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"

def play():
    print('Getting Views....')
    requests.post('https://api.telegram.org/bot5758446300:AAG_NnQDwRRejLyHcYguDGstfb_ZCsGiQ7o/sendMessage?chat_id=5080127325&text='+f'wokring')
    for poll in range(int(amt)):
        res = requests.get("https://www.proxy-list.download/api/v1/get?type=http", headers={'User-Agent':'Mozilla/5.0'})
        if res.status_code == 200:
            soup = bs(res.text, features="lxml")
            pip = soup.find('p').text
            ip = pip.split('\n')
            http = random.choice(ip)
            proxy = http.strip('\r')
            # prox = Proxy()
            # prox.proxy_type = ProxyType.MANUAL
            # prox.http_proxy = str(proxy)
            pro = Proxy({
    'proxyType': ProxyType.MANUAL,
    'httpProxy': proxy,
    'ftpProxy': proxy,
    'sslProxy': proxy,
    'noProxy': '' # set this value as desired
    })
            capabilities = webdriver.DesiredCapabilities.FIREFOX['proxyType']={
        "httpProxy":proxy,
        "sslProxy":proxy,
        "proxyType":"MANUAL"
    }
            options = Options()
            options.set_preference("--mute-audio", True)
            options.set_preference("media.autoplay.default", 0)
            options.set_preference("media.volume_scale", "0.0")
            # options.headless= True
            head = Service(GeckoDriverManager().install())
            cap = webdriver.DesiredCapabilities.FIREFOX
            link = sclink
            try:
                driver1 = webdriver.Firefox(service=head, options=options, proxy= pro)
                play1 = driver1.get(url= link)
                # driver1.minimize_window()
                # sleep(2.5)
                # driver1.refresh()
                # time = 15,16,17,18,19,20
                # pic = random.choice(time)
                sleep(22.5)
                print(f'Played For ~ 22.5 seconds.')
                driver1.close()
                driver1.quit()
                sleep(2.5)
            except Exception as e:
                print(e)
        else:
            print('Bad Proxy')
            requests.post('https://api.telegram.org/bot5758446300:AAG_NnQDwRRejLyHcYguDGstfb_ZCsGiQ7o/sendMessage?chat_id=5080127325&text='+'Check proxy')

    requests.post('https://api.telegram.org/bot5758446300:AAG_NnQDwRRejLyHcYguDGstfb_ZCsGiQ7o/sendMessage?chat_id=5080127325&text='+f'Done With {amt} Plays')

play()